# BotDiscordPy
Bot para Discord feito em Python para controle de algumas funcionalidades do meu servidor, como puxar todos os usuários, criar partidas personalizadas e afins.
