import discord
from discord.ext import commands

class MoveOnReact(commands.Cog):
    def __init__(self,client):
        self.client = client
    
    @commands.command(name = 'moveOnReact')
    @commands.has_role(785650860125978635)
    async def moveOnReact(self,ctx):
        await ctx.message.delete()  
        embed_message = discord.Embed(
            title = f"🎅 │ **{ctx.guild.name}**",
            description = f"**Reaja a esta mensagem**",
            color = 0xFF0004,
        )
        embed_message.set_thumbnail(url = ctx.guild.icon.replace(format="png").url)
        message = await ctx.send(embed = embed_message)
        await message.add_reaction('🚨')
        def check(reaction,user):
          return str(reaction) == '🚨' 
        reaction,user = await self.client.wait_for("reaction_add",check = check)
        channel = await self.client.fetch_channel(854680472206442537)
        await user.move_to(channel)

      
async def setup(client):
    await client.add_cog(MoveOnReact(client))